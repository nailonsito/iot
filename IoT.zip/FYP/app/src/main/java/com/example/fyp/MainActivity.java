package com.example.fyp;

import android.app.ProgressDialog;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;

public class MainActivity extends AppCompatActivity {
    private EditText uEmail;
    private EditText uPassword;
    private Button login;
    private TextView userRegister;
    private TextView attempts;
    private TextView resetPass;
    private int counter = 5;
    private ProgressDialog pdialog;
    private FirebaseAuth fba; //to import library of authentication firebase

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        setupUIViews();

        pdialog = new ProgressDialog(this);
        fba = FirebaseAuth.getInstance();
        FirebaseUser user = fba.getCurrentUser(); //checks if the current user is logged in
//        if (user != null) {
//            finish();
//            startActivity(new Intent(MainActivity.this, HomeActivity.class));
//        }


        login.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                validate(uEmail.getText().toString(), uPassword.getText().toString());
            }
        });

        userRegister.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(MainActivity.this, RegisterActivity.class));
            }
        });

        resetPass.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(MainActivity.this, ForgotPassword.class));
            }
        });

    }

    private void setupUIViews() {
        uEmail = (EditText) findViewById(R.id.login_txt);
        uPassword = (EditText) findViewById(R.id.pass_txt);
        login = (Button) findViewById(R.id.login_btn);
        attempts = (TextView) findViewById(R.id.attempt);
        attempts.setText("Number of attempts remaining: 5");
        userRegister = (TextView) findViewById(R.id.tvRegister);
        resetPass = (TextView) findViewById(R.id.resPass);

    }

    private void validate(String userName, String userPassword) {
        if(userName.isEmpty() || userPassword.isEmpty()) {
            Toast.makeText(MainActivity.this, "Please enter all the details", Toast.LENGTH_SHORT).show();
        } else {
            pdialog.setMessage("Please wait");
            pdialog.show();
            fba.signInWithEmailAndPassword(userName, userPassword).addOnCompleteListener(new OnCompleteListener<AuthResult>() {
                @Override
                public void onComplete(@NonNull Task<AuthResult> task) {
                    if(task.isSuccessful()){
                        pdialog.dismiss();
                        Toast.makeText(MainActivity.this, "Login successful", Toast.LENGTH_SHORT).show();
                        startActivity(new Intent(MainActivity.this, HomeActivity.class));
                    } else {
                        pdialog.dismiss();
                        Toast.makeText(MainActivity.this, "Login failed", Toast.LENGTH_SHORT).show();
                        counter--;
                        attempts.setText("Number of attempts remaining: " + counter);
                        if (counter == 0){
                            login.setEnabled(false);
                        }
                    }
                }
            });
        }
    }
}