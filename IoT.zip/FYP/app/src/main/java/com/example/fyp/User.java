package com.example.fyp;

public class User {
    public String name_txt;
    public String user_mail;

    public User () {

    }


    public User (String name_txt, String user_mail) {
        this.name_txt = name_txt;
        this.user_mail = user_mail;
    }
}
