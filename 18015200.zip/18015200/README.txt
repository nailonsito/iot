This file contains:
Coursework report
A zip file which contains the Android Studio code
A python file wich contains the code for Raspberry Pi